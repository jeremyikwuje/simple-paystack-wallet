A plain and basic PHP wallet implementation with Paystack.

## Installation
Please, check the config file and enter your database settings.

Also, don't forget to put the BASE of this wallet in the config file.

If you're on XAMPP: 

http://localhost/wallet

PHP console:

http://localhost:8000  ( depending the port you use )

Live Server:

Just enter your domain name: http://mydomain.com

## Author
I'm Jeremiah Ikwuje, a software developer in Nigeria.

Thanks, you can follow me on Twitter <https://twitter.com/ijsucceed>

